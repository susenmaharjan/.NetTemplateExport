﻿namespace $safeprojectname$.DataAccess.Data
{
    public class DataConstants
    {
    }
}